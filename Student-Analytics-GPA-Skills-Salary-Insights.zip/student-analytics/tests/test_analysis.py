import numpy as np

from src.analysis import clean_data, data_quality_report, placed_only, run_statistics, train_models
from src.generate_dataset import generate

RAW = generate(n=400, seed=7)


def test_generator_is_reproducible():
    assert generate(n=100, seed=1).equals(generate(n=100, seed=1))


def test_salary_exists_only_for_placed_students():
    assert RAW.loc[RAW["placed"] == 0, "salary_lpa"].isna().all()
    assert RAW.loc[RAW["placed"] == 1, "salary_lpa"].notna().all()


def test_cleaning_removes_duplicates_and_gaps():
    clean = clean_data(RAW)
    assert clean["student_id"].is_unique
    assert len(clean) == 400
    assert clean[["sql", "certifications", "communication"]].isna().sum().sum() == 0
    assert clean["gpa"].between(0, 10).all()
    assert {"avg_skill", "gpa_band"} <= set(clean.columns)


def test_quality_report_counts_duplicates():
    report = data_quality_report(RAW, clean_data(RAW))
    assert report["duplicate_rows_removed"] == 8
    assert report["rows_clean"] == 400


def test_statistics_have_expected_direction():
    stats = run_statistics(clean_data(RAW))
    assert stats["gpa_salary_pearson"][0] > 0.2
    assert stats["skill_salary_corr"]["python"] > stats["skill_salary_corr"]["communication"]
    assert stats["internship_mean_with"] > stats["internship_mean_without"]


def test_models_return_sane_scores_and_importances():
    models, importance = train_models(clean_data(RAW))
    assert models["linear_all"]["r2"] > models["linear_gpa_only"]["r2"]
    assert np.isclose(importance.sum(), 1.0)
    assert "department" in importance.index


def test_placed_only_has_salary():
    assert placed_only(clean_data(RAW))["salary_lpa"].notna().all()
