"""Generate a synthetic student dataset (data/students.csv).

The data is simulated, NOT real student records. Relationships between GPA, skills,
internships and salary are built in with realistic noise so the analysis has something
to find. Replace data/students.csv with real data that has the same columns to reuse
the whole pipeline.

Run:  python -m src.generate_dataset
"""
from pathlib import Path

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent.parent / "data" / "students.csv"

# department -> (share of students, python, sql, ml, excel base skill means, salary premium in LPA)
DEPARTMENTS = {
    "Computer Science": (0.28, 70, 62, 55, 45, 2.0),
    "Information Technology": (0.20, 66, 64, 45, 50, 1.6),
    "Data Science": (0.12, 72, 70, 72, 55, 2.8),
    "Electronics": (0.20, 50, 42, 35, 40, 0.8),
    "Mechanical": (0.20, 35, 35, 22, 45, 0.0),
}


def generate(n=1200, seed=42):
    rng = np.random.default_rng(seed)
    names = list(DEPARTMENTS)
    probs = [DEPARTMENTS[d][0] for d in names]
    dept = rng.choice(names, size=n, p=probs)

    aptitude = rng.normal(0, 1, n)  # hidden trait that nudges both GPA and skills
    gpa = np.clip(rng.normal(7.2, 0.9, n) + 0.45 * aptitude, 4.5, 10.0).round(2)

    def skill(col):
        base = np.array([DEPARTMENTS[d][col] for d in dept], dtype=float)
        return np.clip(base + 4 * (gpa - 7.2) + 6 * aptitude + rng.normal(0, 11, n), 0, 100).round(0)

    python, sql, ml, excel = skill(1), skill(2), skill(3), skill(4)
    communication = np.clip(rng.normal(60, 14, n) + 3 * aptitude, 10, 100).round(0)
    avg_skill = (python + sql + ml + excel) / 4

    internships = np.minimum(rng.poisson(0.5 + 0.7 * (avg_skill > 55)), 4)
    projects = np.minimum(rng.poisson(np.clip(2 + 0.03 * (avg_skill - 50), 0.3, None)), 8)
    certifications = np.minimum(rng.poisson(np.clip(1.2 + 0.02 * (avg_skill - 50), 0.2, None)), 6)
    city_tier = rng.choice([1, 2, 3], size=n, p=[0.35, 0.40, 0.25])
    gender = rng.choice(["Female", "Male"], size=n, p=[0.42, 0.58])
    grad_year = rng.choice([2022, 2023, 2024, 2025], size=n)

    logit = (0.7 + 0.55 * (gpa - 7.2) + 0.03 * (avg_skill - 50) + 0.4 * internships
             + 0.012 * (communication - 60) + 0.1 * projects)
    placed = (rng.random(n) < 1 / (1 + np.exp(-logit))).astype(int)

    dept_prem = np.array([DEPARTMENTS[d][5] for d in dept])
    tier_prem = np.select([city_tier == 1, city_tier == 2], [1.2, 0.4], 0.0)
    salary = (2.2 + dept_prem + tier_prem + 0.7 * (gpa - 7.2)
              + 0.03 * python + 0.028 * ml + 0.018 * sql + 0.008 * excel + 0.012 * communication
              + 0.55 * internships + 0.15 * projects + 0.1 * certifications)
    salary = np.clip(salary * rng.lognormal(0, 0.16, n) - 2.0, 2.4, 45).round(2)
    salary = np.where(placed == 1, salary, np.nan)

    df = pd.DataFrame({
        "student_id": [f"S{i:04d}" for i in range(1, n + 1)],
        "department": dept, "gender": gender, "graduation_year": grad_year, "city_tier": city_tier,
        "gpa": gpa, "python": python, "sql": sql, "excel": excel, "ml": ml,
        "communication": communication, "internships": internships, "projects": projects,
        "certifications": certifications, "placed": placed, "salary_lpa": salary,
    })

    # Real data is messy: blank a few values and repeat a few rows so cleaning has a purpose.
    for col in ["sql", "certifications", "communication"]:
        df.loc[rng.choice(n, size=int(0.02 * n), replace=False), col] = np.nan
    return pd.concat([df, df.sample(8, random_state=seed)], ignore_index=True)


if __name__ == "__main__":
    data = generate()
    OUT.parent.mkdir(exist_ok=True)
    data.to_csv(OUT, index=False)
    print(f"Wrote {len(data)} rows to {OUT}")
