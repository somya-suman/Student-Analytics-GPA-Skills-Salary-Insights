"""Cleaning, statistics, models and charts for the student analytics project.

Run everything:  python -m src.analysis
Every function is importable, so the notebook reuses exactly the same code.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "students.csv"
FIG_DIR = ROOT / "reports" / "figures"

SKILLS = ["python", "sql", "ml", "excel"]
NUMERIC = ["gpa", *SKILLS, "communication", "internships", "projects", "certifications"]
GPA_BANDS = [0, 6, 7, 8, 9, 10.01]
GPA_LABELS = ["< 6", "6 - 7", "7 - 8", "8 - 9", "9 - 10"]
ACCENT, MUTED = "#1f7a63", "#8aa39b"


# --------------------------------------------------------------------------- data
def load_data(path=DATA):
    return pd.read_csv(path)


def clean_data(df):
    """Drop repeated students, fill gaps with the column median, add helper columns."""
    df = df.drop_duplicates(subset="student_id").copy()
    for col in ["sql", "certifications", "communication"]:
        df[col] = df[col].fillna(df[col].median())
    df = df[df["gpa"].between(0, 10)]
    df["avg_skill"] = df[SKILLS].mean(axis=1)
    df["gpa_band"] = pd.cut(df["gpa"], bins=GPA_BANDS, labels=GPA_LABELS, right=False)
    return df.reset_index(drop=True)


def data_quality_report(raw, clean):
    return {
        "rows_raw": int(len(raw)),
        "duplicate_rows_removed": int(raw.duplicated(subset="student_id").sum()),
        "missing_values_filled": int(raw.drop(columns="salary_lpa").isna().sum().sum()),
        "rows_clean": int(len(clean)),
        "salary_missing_for_unplaced": int(clean["salary_lpa"].isna().sum()),
    }


def placed_only(df):
    return df[df["placed"] == 1].dropna(subset=["salary_lpa"])


# ---------------------------------------------------------------------- statistics
def run_statistics(df):
    p = placed_only(df)
    pear = stats.pearsonr(p["gpa"], p["salary_lpa"])
    spear = stats.spearmanr(p["gpa"], p["salary_lpa"])
    place = stats.pearsonr(df["gpa"], df["placed"])
    groups = [g["salary_lpa"].values for _, g in p.groupby("department")]
    anova = stats.f_oneway(*groups)
    with_i = p.loc[p["internships"] >= 1, "salary_lpa"]
    without = p.loc[p["internships"] == 0, "salary_lpa"]
    ttest = stats.ttest_ind(with_i, without, equal_var=False)
    skill_corr = p[SKILLS + ["communication"]].corrwith(p["salary_lpa"]).sort_values(ascending=False)
    return {
        "placement_rate": float(df["placed"].mean()),
        "median_salary_lpa": float(p["salary_lpa"].median()),
        "mean_salary_lpa": float(p["salary_lpa"].mean()),
        "gpa_salary_pearson": [float(pear.statistic), float(pear.pvalue)],
        "gpa_salary_spearman": [float(spear.statistic), float(spear.pvalue)],
        "gpa_placed_corr": [float(place.statistic), float(place.pvalue)],
        "department_anova_f": [float(anova.statistic), float(anova.pvalue)],
        "internship_mean_with": float(with_i.mean()),
        "internship_mean_without": float(without.mean()),
        "internship_ttest": [float(ttest.statistic), float(ttest.pvalue)],
        "skill_salary_corr": {k: float(v) for k, v in skill_corr.items()},
    }


def group_tables(df):
    p = placed_only(df)
    by_dept = (df.groupby("department")
               .agg(students=("student_id", "count"), placement_rate=("placed", "mean"),
                    avg_gpa=("gpa", "mean"))
               .join(p.groupby("department")["salary_lpa"].agg(median_salary="median", mean_salary="mean")))
    by_band = (df.groupby("gpa_band", observed=True)
               .agg(students=("student_id", "count"), placement_rate=("placed", "mean"))
               .join(p.groupby("gpa_band", observed=True)["salary_lpa"].median().rename("median_salary")))
    return by_dept.round(2).sort_values("median_salary", ascending=False), by_band.round(2)


# ------------------------------------------------------------------------- models
def _features(df):
    X = df[NUMERIC + ["city_tier"]].copy()
    return X.join(pd.get_dummies(df["department"], prefix="dept", dtype=float))


def train_models(df, seed=42):
    p = placed_only(df)
    X, y = _features(p), p["salary_lpa"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=seed)

    def score(model, cols):
        model.fit(X_tr[cols], y_tr)
        pred = model.predict(X_te[cols])
        return {"r2": float(r2_score(y_te, pred)), "mae": float(mean_absolute_error(y_te, pred))}

    all_cols = list(X.columns)
    gpa_cols = ["gpa"]
    skill_cols = SKILLS + ["communication"]
    results = {
        "linear_gpa_only": score(LinearRegression(), gpa_cols),
        "linear_skills_only": score(LinearRegression(), skill_cols),
        "linear_all": score(LinearRegression(), all_cols),
        "random_forest_all": score(RandomForestRegressor(300, random_state=seed, n_jobs=-1), all_cols),
    }
    rf = RandomForestRegressor(300, random_state=seed, n_jobs=-1).fit(X_tr, y_tr)
    imp = pd.Series(rf.feature_importances_, index=X.columns)
    dept_total = imp.filter(like="dept_").sum()
    imp = imp.drop(imp.filter(like="dept_").index)
    imp["department"] = dept_total
    return results, imp.sort_values(ascending=False)


# ------------------------------------------------------------------------- charts
def _style():
    sns.set_theme(style="whitegrid", context="notebook", font_scale=1.0)
    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 110})


def plot_gpa_distribution(df):
    _style()
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.histplot(df["gpa"], bins=24, kde=True, color=ACCENT, ax=ax)
    ax.axvline(df["gpa"].median(), color="#333", ls="--", lw=1)
    ax.text(df["gpa"].median() + 0.05, ax.get_ylim()[1] * 0.92, f"median {df['gpa'].median():.2f}", fontsize=9)
    ax.set(title="GPA is centred just above 7", xlabel="GPA (out of 10)", ylabel="Students")
    fig.tight_layout()
    return fig


def plot_correlation_heatmap(df):
    _style()
    cols = NUMERIC + ["salary_lpa"]
    corr = placed_only(df)[cols].corr()
    fig, ax = plt.subplots(figsize=(8, 6.5))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="BrBG", center=0, vmin=-1, vmax=1,
                linewidths=.5, cbar_kws={"shrink": .8}, ax=ax)
    ax.set_title("Correlations among placed students")
    fig.tight_layout()
    return fig


def plot_gpa_vs_salary(df):
    _style()
    p = placed_only(df)
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    sns.scatterplot(data=p, x="gpa", y="salary_lpa", hue="department", alpha=.65, s=28, ax=ax)
    sns.regplot(data=p, x="gpa", y="salary_lpa", scatter=False, color="#222", line_kws={"lw": 1.8}, ax=ax)
    r = stats.pearsonr(p["gpa"], p["salary_lpa"]).statistic
    ax.set(title=f"Higher GPA goes with higher pay, but loosely (r = {r:.2f})",
           xlabel="GPA (out of 10)", ylabel="Salary (LPA)")
    ax.legend(title="", fontsize=8, frameon=False)
    fig.tight_layout()
    return fig


def plot_skills_vs_salary(df):
    _style()
    p = placed_only(df)
    fig, axes = plt.subplots(2, 2, figsize=(9, 7), sharey=True)
    for ax, skill in zip(axes.ravel(), SKILLS):
        sns.regplot(data=p, x=skill, y="salary_lpa", scatter_kws={"alpha": .35, "s": 14, "color": MUTED},
                    line_kws={"color": ACCENT, "lw": 2}, ax=ax)
        r = p[skill].corr(p["salary_lpa"])
        ax.set(title=f"{skill.upper() if skill != 'excel' else 'Excel'} (r = {r:.2f})",
               xlabel="Skill score (0-100)", ylabel="Salary (LPA)")
    fig.suptitle("Technical skill scores against salary", y=1.0)
    fig.tight_layout()
    return fig


def plot_salary_by_department(df):
    _style()
    p = placed_only(df)
    order = p.groupby("department")["salary_lpa"].median().sort_values(ascending=False).index
    fig, ax = plt.subplots(figsize=(8, 4.5))
    sns.boxplot(data=p, y="department", x="salary_lpa", order=order, color=MUTED, fliersize=2, ax=ax)
    ax.set(title="Salary by department", xlabel="Salary (LPA)", ylabel="")
    fig.tight_layout()
    return fig


def plot_placement_by_gpa(df):
    _style()
    band = df.groupby("gpa_band", observed=True)["placed"].mean().mul(100)
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.barplot(x=band.index.astype(str), y=band.values, color=ACCENT, ax=ax)
    for i, v in enumerate(band.values):
        ax.text(i, v + 1, f"{v:.0f}%", ha="center", fontsize=9)
    ax.set(title="Placement rate climbs with GPA band", xlabel="GPA band", ylabel="Placed (%)", ylim=(0, 105))
    fig.tight_layout()
    return fig


def plot_feature_importance(importance):
    _style()
    imp = importance.sort_values()
    fig, ax = plt.subplots(figsize=(7, 4.8))
    ax.barh(imp.index, imp.values, color=[ACCENT if v == imp.max() else MUTED for v in imp.values])
    ax.set(title="What the random forest relies on to predict salary", xlabel="Importance")
    fig.tight_layout()
    return fig


def plot_internship_effect(df):
    _style()
    p = placed_only(df).assign(internships=lambda d: d["internships"].clip(upper=3).astype(int).astype(str))
    p["internships"] = p["internships"].replace({"3": "3+"})
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    sns.barplot(data=p, x="internships", y="salary_lpa", order=["0", "1", "2", "3+"], color=ACCENT,
                errorbar=("ci", 95), ax=ax)
    ax.set(title="Each internship adds to average salary", xlabel="Internships completed", ylabel="Mean salary (LPA)")
    fig.tight_layout()
    return fig


CHARTS = {
    "01_gpa_distribution": plot_gpa_distribution,
    "02_correlation_heatmap": plot_correlation_heatmap,
    "03_gpa_vs_salary": plot_gpa_vs_salary,
    "04_skills_vs_salary": plot_skills_vs_salary,
    "05_salary_by_department": plot_salary_by_department,
    "06_placement_by_gpa_band": plot_placement_by_gpa,
    "07_internship_effect": plot_internship_effect,
}


# --------------------------------------------------------------------------- main
def main():
    import matplotlib

    matplotlib.use("Agg")
    FIG_DIR.mkdir(parents=True, exist_ok=True)

    raw = load_data()
    df = clean_data(raw)
    quality = data_quality_report(raw, df)
    results = run_statistics(df)
    models, importance = train_models(df)
    by_dept, by_band = group_tables(df)

    for name, fn in CHARTS.items():
        fig = fn(df)
        fig.savefig(FIG_DIR / f"{name}.png", bbox_inches="tight")
        plt.close(fig)
    fig = plot_feature_importance(importance)
    fig.savefig(FIG_DIR / "08_feature_importance.png", bbox_inches="tight")
    plt.close(fig)

    out = {"quality": quality, "statistics": results, "models": models,
           "importance": {k: float(v) for k, v in importance.items()}}
    (ROOT / "reports" / "results.json").write_text(json.dumps(out, indent=2))
    (ROOT / "reports" / "department_summary.csv").write_text(by_dept.to_csv())
    (ROOT / "reports" / "gpa_band_summary.csv").write_text(by_band.to_csv())

    print(json.dumps(out, indent=2))
    print("\n", by_dept, "\n\n", by_band)
    print(f"\nSaved {len(CHARTS) + 1} charts to {FIG_DIR}")


if __name__ == "__main__":
    main()
