# Data

`students.csv` is **synthetic**. It was produced by `python -m src.generate_dataset` (seed 42) and contains no real people.

| Column | Meaning |
|--------|---------|
| student_id | Unique id (a few rows are repeated on purpose to practise cleaning) |
| department | Computer Science, Information Technology, Data Science, Electronics, Mechanical |
| gender | Female or Male |
| graduation_year | 2022 to 2025 |
| city_tier | 1 (metro) to 3 |
| gpa | Out of 10 |
| python, sql, excel, ml | Skill scores from 0 to 100 |
| communication | Score from 0 to 100 |
| internships, projects, certifications | Counts |
| placed | 1 if the student got a job offer, else 0 |
| salary_lpa | Offer in lakh rupees per year; blank when not placed |

To analyse real data, replace `students.csv` with a file that has the same columns.
