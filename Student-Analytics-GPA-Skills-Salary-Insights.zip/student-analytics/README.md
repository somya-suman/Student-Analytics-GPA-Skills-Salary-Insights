# Student Analytics: GPA, Skills and Salary Insights

A data analysis project that explores how students' **GPA**, **technical skills**, **internships** and **department** relate to **placement** and **salary**. Built with Python, Pandas, SciPy, scikit-learn and Seaborn.

![Python](https://img.shields.io/badge/python-3.10%2B-blue) ![pandas](https://img.shields.io/badge/pandas-2.x-150458) ![License](https://img.shields.io/badge/license-MIT-green)

> **About the data:** the dataset is **synthetic** (1,200 simulated students, generated with a fixed seed by `src/generate_dataset.py`). It contains no real people, and the findings describe the simulation. The pipeline works on real data too: swap in a CSV with the same columns (see [`data/README.md`](data/README.md)).

## Questions answered

1. Does a higher GPA lead to a higher salary?
2. Which technical skills move salary the most?
3. How much do department and internships matter?
4. How well can salary be predicted, and from which inputs?

## Key findings

| Finding | Result |
|---------|--------|
| Placement rate | **72.5%** of students placed |
| Median salary (placed) | **8.6 LPA** (mean 8.8 LPA) |
| GPA and salary | Moderate link: Pearson **r = 0.42** (p < 0.001) |
| GPA alone as a predictor | Explains only **10%** of salary variation (R² = 0.10) |
| Skills alone as predictors | Explain **55%** (R² = 0.55), over five times more than GPA |
| Strongest skills | Python (r = 0.70) and ML (r = 0.70), then SQL (0.65) and Excel (0.36). Communication score is almost unrelated (0.07) |
| Internships | Students with at least one internship earn **9.6 vs 7.8 LPA** (Welch t-test, p < 0.001) |
| Department | Median salary ranges from **11.7 LPA (Data Science)** to **5.1 LPA (Mechanical)** (ANOVA F = 152.8, p < 0.001) |
| GPA and placement | Placement rises from **45%** (GPA below 6) to **98%** (GPA 9 to 10) |

**In short:** GPA helps you get placed and nudges salary up, but what students can *do* (Python, ML, SQL), plus internships, tells you far more about pay than the grade does.

### Charts

| | |
|---|---|
| ![GPA vs salary](reports/figures/03_gpa_vs_salary.png) | ![Skills vs salary](reports/figures/04_skills_vs_salary.png) |
| ![Placement by GPA band](reports/figures/06_placement_by_gpa_band.png) | ![Salary by department](reports/figures/05_salary_by_department.png) |
| ![Internship effect](reports/figures/07_internship_effect.png) | ![Feature importance](reports/figures/08_feature_importance.png) |

More: [GPA distribution](reports/figures/01_gpa_distribution.png) and the [correlation heatmap](reports/figures/02_correlation_heatmap.png).

### Salary prediction

Trained on 80% of placed students, scored on the other 20%.

| Model | Inputs | R² | Mean error (LPA) |
|-------|--------|----|------------------|
| Linear regression | GPA only | 0.10 | 2.30 |
| Linear regression | Skills only | 0.55 | 1.61 |
| Linear regression | Everything | **0.68** | **1.33** |
| Random forest | Everything | 0.54 | 1.59 |

The random forest scores below the linear model here because the relationships in this data are close to linear and the test set is small. The forest ranks **Python (43%)**, **ML (17%)**, **GPA (10%)** and **SQL (9%)** as the most important inputs.

## Method

1. **Clean:** drop repeated student ids (8 removed), fill 72 blank values with column medians, check GPA range.
2. **Explore:** distributions, group summaries, correlation matrix.
3. **Test:** Pearson and Spearman correlation, one-way ANOVA across departments, Welch t-test for internships.
4. **Model:** linear regression and random forest with a train/test split.
5. **Visualise:** eight charts saved to `reports/figures/`.

Salary exists only for placed students, so salary analysis uses placed students only. Placement analysis uses everyone.

## Run it

```bash
git clone https://github.com/<your-username>/Student-Analytics-GPA-Skills-Salary-Insights.git
cd Student-Analytics-GPA-Skills-Salary-Insights

python -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt

python -m src.generate_dataset      # optional: rebuild data/students.csv
python -m src.analysis              # prints results, saves charts and reports/
jupyter notebook notebooks/analysis.ipynb
pytest                              # run the tests
```

## Project structure

```
├── data/
│   ├── students.csv               # synthetic dataset
│   └── README.md                  # column dictionary
├── notebooks/analysis.ipynb       # step-by-step walkthrough
├── reports/
│   ├── figures/                   # 8 charts
│   ├── results.json               # every statistic and model score
│   ├── department_summary.csv
│   └── gpa_band_summary.csv
├── src/
│   ├── generate_dataset.py        # builds the synthetic data
│   └── analysis.py                # cleaning, statistics, models, charts
├── tests/test_analysis.py
└── requirements.txt
```

## Limitations

- The data is simulated, so real campuses will differ.
- Correlation is not causation. Students who do well in both GPA and skills may share traits (motivation, aptitude) that drive both, so raising one score alone may not raise pay.
- Salary figures are in LPA (lakh rupees per year) and ignore bonuses, stock and cost of living.
- Only 876 placed students feed the salary models, so scores shift a little with a different random split.

## Ideas for next steps

- Run the pipeline on real placement data (with consent and anonymisation)
- Predict placement (yes or no) with logistic regression
- Compare gender and city tier for pay gaps
- Build an interactive dashboard with Streamlit

## License

[MIT](LICENSE)
